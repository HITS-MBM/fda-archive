/*
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.3.1
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2004, The GROMACS development team,
 * check out http://www.gromacs.org for more information.
 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Green Red Orange Magenta Azure Cyan Skyblue
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef _FMIO_H_
#define _FMIO_H_

#include "types/forcemat.h"
#include "types/simple.h"
#include "typedefs.h"
#include "fmsparse.h"
#include "fmutils.h"

/*! \brief Utilities to write and read matrices containing pairwise 
 * atomic forces.
 * For ascii files data is stored as name=value pairs.
 * The file contains n-blocks containing all non-zero elements of the 
 * forcematrix. Each block starts with <begin_block> and ends with
 * <end_block>. See forcemat_write_ascii_block for more information.
 * When binary writing is selected, data is stored into n consecutive
 * binary blocks, see forcemat_write_binary_block for more information.
 * 
 * Independent of the selected output format the file will always contain
 * an ascii encoded header. This header basically stores the t_fmpar structure
 * and sizes of int and real values.
 * 
 * Comments are marked by ';' as first character.
 *
 * Author: 	Wolfram Stacklies
 *		wolfram.stacklies@gmail.com
 */ 

#define FM_VERSION "1.2"
/* Tags to add at the beginning and end of a block if forces
 * are written out as ascii file */
#define BEGINBLOCK "<begin_block>\n"
#define ENDBLOCK "<end_block>\n"
/* Maximum length of strings */
#define FM_STRLEN 10000
#define FM_NAMELEN 255
/* Mark the end of an entry in binary output files */
#define NEW_ENTRY -280480

/* !\brief Open a file to write forces.
 *
 * The function also calles forcemat_write_head to write
 * the file header 
 *
 * \param filename - Name of the file to open
 * \param forcemat - A forcemat structure. The matrix is not written to 
 * the file, the structue is needed to write general information as
 * dimensions and such.
 * \param fmpar - Parameters as read from the .fi input file, these will be
 * written into the header.
 * \return A pointer to the opened file.
*/
FILE* 
forcemat_fopen(char * filename, const t_forcemat *forcemat, const t_fmpar *fmpar);

/* !\brief Close the forcematrix file, automatically append
 * binary "EOF" string.
 *
 * \param file filepointer
 */
void 
forcemat_fclose(FILE * file);

/* \!brief write the header of the forcematrix file. 
 *
 * The header is always ascii encoded, no matter if the information 
 * is stored binary or not. Information is stored as name=value pairs.
 * Names are:
 * - groupname	: name of the group storing the atoms for which forces
 *                are written out.
 * - writefreq	: How often are forces written out (number of timesteps)
 * - sysanr	: Total number of atoms in the system
 * - fmdim	: Dimension of the (square) force matrix
 * - intsize	: sizeof(int)
 * - realsize	: sizeof(real)
 * \param file filepointer
 * \param forcemat initialized forcematrix
 * \param fmpar Data read from force input file
 */
void
forcemat_write_head(FILE* file, const t_forcemat *forcemat, const t_fmpar* fmpar);

/* Another interface to forcemat_write_head. It does not require an initialized
 * forcematrix or an fmpar structure.
 *
 * \param file filepointer
 * \param groupname name of the index group for which forces are written out
 * \param writefreq how often are forces written out (no of timesteps)
 * \param nsteps (expected) number of writesteps
 * \param sysanr the forcemat->sysanr array
 * \param fmdim dimension of the forcematrix
 */
void 
forcemat_write_head_raw(FILE* file, char *groupname, 
			int writefreq, int nsteps, int sysanr, int fmdim);


/* !\brief Write the forcematrix in binary encoding.
 *
 * The data is written in consecutive integer / real blocks.
 * Each block ends with the integer value -1000. This can be
 * used to check for errors while reading. 
 * The sucessive blocks are:
 * - int  (1)		: Block number (timesteps / writefreq)
 * - int  (1)		: Number of non-zero entries in the forcematrix
 * - int  (fmdim)	: The fmatom_id array, see t_forcemat
 * - int  (nz-values)	: Indices of the non-zero entries in the forcematrix
 * - real (nz_values)	: Non-zero force vectors (stored as rvec)
 * \param file filepointer
 * \param forcemat Data to write into the block
 * \param iteration Block ID, number of timesteps / writefreq
 * \param symm TRUE if the matrix is symmetric (write only half of the entries), 
 * FALSE if not
 */
void 
forcemat_write_binary_block(FILE* file, const t_forcemat* forcemat, int iteration);

/* This is just another interface to forcemat_write_binary_block. It does
 * not need an initialized forcematrix.
 *
 * \param file filepointer
 * \param fmatom_id forcemat->fmatom_id
 * \param nz_index forcemat->nz_index
 * \param nz_fvecs Non-zero vectors in the forcematrix
 * \param interaction Interactions for non-zero force vectors
 * \param nz_asize number of non-zero vectors
 * \param fmdim dimension of the forcematrix
 * \param iteration current iteration (= write step)
 */
void 
forcemat_write_binary_block_raw(FILE *file, int *fmatom_id, int *index, real *force,
                                char *interaction, int asize, int natoms, int iteration);


/* !\brief Write a variance matrix to the given file.
 * This is a very specific helper function and is mainly used to 
 * write the variance matrix in md.c. The matrix has to contain
 * exactely three frames. Frame zero containing the variances will
 * be diveded by frame 2 containig the number of non-zero forces.
 * There are other and more convenient routines for I/O handling
 * in fmio.h and tools/g_forcemat.h that should be used instead.
 * \param out force-matrix output file
 * \param smat Sparse matrix containing variances in pairwise
 * forces. The matrix has to contain three frames (variance
 * estimat, mean estimate and number of non-zero entries).
 * The method will write the first frame only.
 */
void
forcemat_write_variance(char *out, t_fmsparse *smat);


/* !\brief Read a block of binary data from a forcematrix file
 *
 * \param file filepointer
 * \param fmdim Dimension of forcematrix
 * \param realsize Realsize of the system that created the file
 * \param intsize Intsize of the system that created the file
 * \param fvectors (out) Non-zero force vectors as read from file.
 * Memory is allocated by the function.
 * \param nz_index (out) Positions of non-zero force vectors in the
 * forcematrix. Memory is allocated by the function.
 * \param nz_asize (out) Number of non-zero force vectors
 * \param fmatom_id (out) Atom Id's of all atoms in the forcematrix.
 * \param interaction Array of interaction types
 * \param iteration (out) Block id
 * \return FALSE if the end of file has been reached, TRUE otherwise.
 */
int 
forcemat_read_binary_block(FILE* file, char* version, int fmdim, int realsize, int intsize,
			   real** force, int** index, int * asize, 
			   int** fmatom_id, char** interaction, int* iteration);


/* Jump (set the file pointer) to a given frame */
bool 
forcemat_jump_to_frame(FILE *file, char* version, int fmdim, int realsize, int intsize,
                       int jumpTo);

/* Resets the file pointer to the initial position before returning!
 * Count the frames in the given forcemat file, as we cannot trust the
 * nsteps record. (A simulation may have crashed, etc.)
 */
int 
forcemat_count_frames(FILE *file, char* version, int fmdim, int realsize, int intsize);


/* !\brief Write the <begin_block> line 
 * \param file filepointer
 */
void 
forcemat_write_beginblock(FILE *file);

/* !\brief Write the <end_block) line 
 * \param file filepointer
 */
void 
forcemat_write_endblock(FILE* file);

/* !\brief Write a comment. Comments have a ';' as first
 * character. Comments somewhere in the line are not supported!!
 *
 * \param file filepointer
 * \param comment Comment string to write to file
 */
void 
forcemat_write_comment(FILE* file, char* comment);

/* !\brief Write a pair of the form name=value to an ascii encoded
 * file.
 *
 * The function just writes name=value and does not do any further
 * checks.
 *
 * \param file filepointer
 * \param name name string
 * \param value value string
 */
void 
forcemat_write_pair(FILE* file, char* name, char* value);

/* !\brief Read an arbitrary block of data from an ascii encoded file.
 *
 * The function returns two char**, one containing the names and
 * the other containing the accoring values. The char** array must
 * already be allocated.
 *
 * \param file filepointer
 * \param names name strings as read from file. Ensure that char** names
 * is large enough to hold all entries.
 * \param asize Number of entries in the names/valeus arrays
 * \param values value strings as read from file. Ensure that char** values
 * is large enough to hold all entries.
 * \return FALSE if the end of file has been reached, TRUE otherwise.
 */
int 
forcemat_read_ascii_data(FILE *file, int* asize, char** names, char** values);

/* !\brief Search for a name in the names list and return the index
 * if the name was found.
 *
 * \param pattern Pattern string to search the names array for.
 * \param names Array with name tags, as returned from forcemat_read_ascii_block.
 * \param values Array with values strings as returned from forcemat_read_ascii_block.
 * \param nvals Number of name/value pairs.
 */
int 
forcemat_get_charvalue(char* pattern, char** names, char** values, int nvals);

/* !\brief Helper function to check if a line is comment or not.
 *
 * The function checks if the first non-blanc character in the line is
 * a comment. Comments somewhere in the line will not be recognized.
 *
 * \param str String to check for leading comment character.
 */
int 
forcemat_is_comment(char * str);

#endif
