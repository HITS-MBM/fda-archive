/*
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.3.1
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2004, The GROMACS development team,
 * check out http://www.gromacs.org for more information.
 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Green Red Orange Magenta Azure Cyan Skyblue
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef _FMUTILS_H_
#define _FMUTILS_H_

#include "types/forcemat.h"
#include "types/simple.h"
#include "fmsparse.h"


/*! \brief Utilities to access and communicate a forcematrix structure
 *
 * Author: Wolfram Stacklies
 *         wolfram.stacklies@gmail.com
 *         05/2007
 */ 


/* !\brief Allocate a new forcematrix structure
 *
 * The matrix is of size fmdim X fmdim, all elements will
 * initially be set zero.
 *
 * \param fmdim Dimension of the forcematrix
 * \param atoms Id's of all atoms in the forcematrix (written into
 * the fmatom_id record).
 * \param sysatoms Total number of atoms in the system
 * \param itype itype structure
 * \param ir inputrec structure. Used to calculate the estimated number of
 * writesteps.
 * \return The allocated and initialized forcematrix. Ready for
 * action :)
 */
t_forcemat *
forcemat_allocate(int natoms, t_fmpar *fmpar, atom_id* atoms, int sysanr);

void 
forcemat_reallocate(t_forcemat *forcemat, int colsize);

real* 
reallocate_forces(real *array, int nrow, int ncol_old, int ncol_new);

int* 
reallocate_index(int *array, int nrow, int ncol_old, int ncol_new);

char* 
reallocate_interaction(char *array, int nrow, int ncol_old, int ncol_new);


void 
forcemat_merge(t_forcemat *forcemat);

/* !\brief Destroy a forcematrix structure, free the memory for
 * all records.
 * \param forcemat Pointer to the forcematrix structure.
 */
void 
forcemat_destroy(t_forcemat * forcemat);

/* !\brief Set all entries in the forcematrix to zero.
 *
 * \param forcemat
 */
void 
forcemat_clear(t_forcemat* forcemat);

void 
forcemat_clear_scratch(t_forcemat* forcemat);


/* !\brief Divide all entries by the given int value. This can be
 * used to average through a number of timesteps.
 * 
 * \param forcemat
 * \param div Value to divide each element by.
 */
void 
forcemat_divide(t_forcemat* forcemat, real div);

/* !\brief Add a vector to the given atoms in the matrix for bonded forces
 *
 * The matrix positions corresponding to the atom_ids are looked
 * up in the fmatoms array.
 * i_pos and j_pos are exchangable as the matrix is square and
 * the vector is added to [i,j] and [j,i].
 * \param forcemat
 * \param i_pos I-atom ID
 * \param j_pos J-atom ID
 * \param fvector Force vector to add.
 * \param x Gromacs force record
 * \param interaction ID for bonded, angle and dihedral forces.
 * See the enumeration in forcemat.h
 */
void 
forcemat_add_bonded(t_forcemat *forcemat, atom_id i, atom_id j, rvec fvector,
                    const rvec *x, int interaction);

void 
forcemat_increment(t_forcemat *forcemat, int row, int col,
                   real force, char interaction);


/* Find position of row, col in sparse force-matrix */
int 
forcemat_find_entry(const t_forcemat *forcemat, int row, int col);


/* !\brief Get the forcevector at position i,j in the matrix.
 *
 * The positions are used as they are. Use forcemat_get_atom if
 * you want to get entries for atom_ids.
 * The matrix is symmetric, so i and j may be exchanged.
 * \param forcemat
 * \param i Row (Column) index
 * \param j Column (Row) index
 * \param fvec (out) Forces at position i,j are written into this rvec
 */ 
t_fm_entry* 
forcemat_get(const t_forcemat *forcemat, int row, int col);

/* !\brief Get the forcevector for atoms with index i,j.
 *
 * The corresponding positions in the matrix are looked up from
 * the fmatoms array.
 * The matrix is symmetric, so i and j may be exchanged.
 * \param forcemat
 * \param i ID of i atom
 * \param j ID of j atom
 * \param fvec (out) Forces at position i,j are written into this rvec
 */ 
t_fm_entry* 
forcemat_get_by_aid(const t_forcemat *forcemat, atom_id row, atom_id col);


/* !\brief Read the index file and return the indices of the atoms in the 
 * given group.
 *
 * The function reads an index file and searches for the group named gname.
 * The whole index file as read by init_index() is returned in groups.
 * An invalid file name or index files with no groups will result in a
 * fatal error.
 *
 * \param indexfile Path to the indexfile
 * \param gname Name of the group specifying the atoms for which pairwise
 * forces will be written out.
 * \param groups Groups as read from the index file.
 * \param grpix Index of group with name gname.
 * \return Id's of the atoms in group named gname.
 */
atom_id* 
forcemat_read_index(char* indexfile, char* gname, t_blocka** groups, int* grpix);

/* !\brief Do all the initialisation, including to parse the input and
 * index files.
 * 
 * Parse the force.fi file and write the values into th t_fmpar structure.
 * The function also calls forcemat_read_index and used the values to
 * readily initialize the forcematrix.
 * \param log Filepointer to the log file (currently no log is written)
 * \param nfile Number of entries in the fnm array.
 * \param fnm Gromacs input parameters
 * \param par Information from force input file is stored here
 * \param x Coordinates of all atoms
 * \param md All atoms in the system
 * \param box Periodic box, needed when calculating the solvent shell
 * \return The completely initialized forcematrix.
 */
t_forcemat* 
forcemat_init(FILE *log, int nfile, t_filenm fnm[], t_fmpar *par, rvec *x,
              const t_mdatoms *md, matrix box, const t_commrec *cr, const t_inputrec *ir,
	      int sysanr);

/*
 * MPI related functions
 */


/* !\brief Pack the forcematrix by removing all entries that are zero.
 *
 * The forcematrix is stored in one array the contains the indices of
 * the non-zero positions and on array that contains no-zero force
 * vectors.
 * \param forcemat Forcemat to compress.
 * \param index (out) Non-zero indices, memory is allocated by the function.
 * \param fvectors (out) Non-zero force vectors.
 * \param interaction Array of interaction types (of length asize)
 * \param asize (out) Number of non-zero entries (array sizes)
 * \param symm Only return non-zero values in the "upper triangle" of
 * the symmetric matrix if set TRUE.
 */
void 
forcemat_compress(const t_forcemat *forcemat, int** index, real** force, 
                  char** interaction, int *asize);


/* !\brief The master gathers the local forcematrices from all nodes
 * and sums them up. This function internally check is we are the master,
 * then it receives the data. Or if it we are a slave, then we will send the data.
 *
 * Communication is only done if the local forcematrices contain non-zero
 * values. As the protein atoms will normally all be simulated on the
 * master node (at least when lyncs is used) empty matrices on the slaves 
 * will very often be the case.
 * The function packs the forcematrix and then communicates it separately
 * for each node.
 * \param forcemat Forcemat to compress and send.
 * \param cr Commrec for MPI communication
 */
/*void 
forcemat_compressed_gather(t_forcemat *forcemat, const t_commrec *cr);
*/

/* Algorithm for iterative variance calculation. The algorithm is described in
 * Donald E. Knuth (1998). The Art of Computer Programming
 * Take care: the resulting variance values need to be divided by the number of
 * iterations after the very last step!
 *
 * \param n Iteration step
 * \param x_fm matrix containing pairwise forces
 * \param mean_fm matrix containing the current estimate of the means
 * \param var_fm matrix containing the current estimate of the variance
 * \param nval number of non-zero entries
 * \param var_fm 
 */
void
forcemat_variance(int n, t_forcemat *forcemat, t_fmsparse *varmat);



#endif
