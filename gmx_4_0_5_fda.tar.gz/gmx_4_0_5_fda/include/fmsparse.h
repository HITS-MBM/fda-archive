#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "typedefs.h"

#ifndef _G_FMSPARSE_H_
#define _G_FMSPARSE_H_

/* Matrix entry */
struct smentry {
	real *force; 		/* Constant vector containing the forces */
	int  col; 		/* Column-index */
	char interaction; 	/* Interaction type */
	struct smentry *next; 	/* Pointer to the next column */
};
typedef struct smentry t_smentry;

/* 
 * The t_fmsparse structure holds a sparse 3-dimensional matrix of dimension
 * NxNxF where N is the number of atoms and F the number of frames (z-dimension), this is
 * how often forces have been written out.
 * The sparse matrix is organized as an array of lists. Each list element holds a vector
 * storing F forces.
 * For convenience the structure stores the number of columns in each row in the ncol array,
 * and the total number of elements in the nentries fiels. These values must be updated
 * each time a new entry is added. The function sm_add and sm_increment take care of that.
 *
 * The structure also contains space for variables read from the file header,
 * these are the same as in the t_fmpar structure (also see forcemat.h).
 */
typedef struct {
	int nrow; 		/* Number of rows in the matrix. This is equal the number of force atoms */
	t_smentry **cols; 	/* Array of length nrow holding the lists of rows */
	int* ncol; 		/* Number of columns (entries) in each row */
	int nframes;		/* Numter of frames in the matrix (the z dimension) */
	int nentries; 		/* Total number of entries */
	atom_id *fmatom_id; 	/* Atom ids */
	t_smentry *current;	/* Current element when iterating over elements */
	int current_row;	/* Current row when iterating over elements */

	/* File header information */
	int sysanr; 		/* Number of atoms in the system */
	int intsize; 		/* size of integer */
	int realsize; 		/* size of real */
	char *groupname; 	/* Name of the force-atom index group */
	char *version;		/* version of force matrix file format */
	int writefreq;		/* output frequency (in simulation steps) */
} t_fmsparse;



/* !\brief Allocate the t_fmsparse structure. 
 * Allocates memory for the cols and ncol arrays. All other fields
 * are set zero / NULL.
 *
 * \param nrow number of matrix rows
 */
void 
sm_init(t_fmsparse *smat);

/* !\brief Destroy a t_fmsparse structure. The function loops over all list elements
 * to free memory */
void 
sm_destroy(t_fmsparse *smat);

/* \!brief Create a new sparse matrix element.
 * The function allocates memory for a force vector of length nframes. Other
 * values are set to zero / NULL.
 * \param nframes Number of frames (writesteps) in the forcematrix
 */
t_smentry* 
sm_new_entry(int nframes);

/* !\brief Add a value, return an error if an entry at this position already exists.
 * This function adds a new values, if necessary a new list entry (t_smentry) is
 * created.
 *
 * \param smat sparse matrix object
 * \param force force scalar to insert
 * \param interaction the interaction type
 * \param row matrix row
 * \param col matrix column
 * \param frame matrix frame (z-dimension)
 * \return pointer to the new / modified entry
 */
t_smentry* 
sm_add(t_fmsparse *smat, real force, char interaction,
       int row, int col, int frame);

/* !\brief Add or increment a value.
 * This function adds a new values or increments existing values. 
 * If necessary a new list entry (t_smentry) is created. This function essentailly does
 * the same as sm_add(). The only difference is that it allows to increment values.
 *
 * \param smat sparse matrix object
 * \param force force scalar to insert
 * \param interaction the interaction type
 * \param row matrix row
 * \param col matrix column
 * \param frame matrix frame (z-dimension)
 * \return pointer to the new / modified entry
 */
t_smentry*
sm_increment(t_fmsparse *smat, real force, char interaction,
	     int row, int col, int frame);


/* \!brief Get the matrix entry at the given position.
 * Returns the matrix entry or NULL if the entry does not exist.
 *
 * \param smat sparse matrix
 * \param row matrix row
 * \param col matrix column
 */
t_smentry* 
sm_get(const t_fmsparse *smat, int row, int col);

/* !\brief Start an iteration over all matrix entries.
 * This function returns the first matrix element and resets the
 * iterator. Further elements can be accessed with the sm_next() function.
 * For iterating, the elements 
 * t_fmsparse->current and
 * t_fmsparse->current_row are used.
 *
 * \param smat sparse matrix
 * \return the first matrix element
 */
t_smentry*
sm_start_iteration(t_fmsparse *smat);

/* !\brief Iterate over matrix entries
 * This function returns the next matrix entry. The return value is
 * only defined if sm_start_iteration() has been called prior to the
 * first execution of this function.
 *
 * \param smat sparse matrix
 * \param row return value: current row
 * \return the next matrix entry, or NULL if no more elements.
 */
t_smentry*
sm_next(t_fmsparse *smat, int *row);

/* !\brief Convert a frame of a sparse matrix into an array.
 * The matrix is converted into an array, what is useful when e.g. writing
 * tha matrix to a file. The matrix is representat as three arrays. The forces,
 * the interactions and an array holding the matrix indices. The size of
 * the arrays (the number of non-zero entries) is returned in asize.
 * Memory is allocated by the function.
 *
 * \param smat sparse matrix
 * \param frame matrix frame (z-dimension) to convert to an array
 * \param force array storing forces
 * \param interaction array storing interactions
 * \param index array storing indices of non-zero elements
 * \param asize length of the arrays
 */
void
sm_to_array(t_fmsparse *smat, int frame, real **force, char **interaction,
	    int **index, int *asize);


/* !\brief Divide all forces in the matrix by the given number.
 * \param smat sparse matrix
 * \param div value to dived all values
 */
void 
sm_divide(t_fmsparse *smat, real div);


/* !\brief Get row / col position for a given index.
 * \param smat sparse matrix
 * \param ix index
 * \param col (output)
 * \param row (output)
 */
void
sm_ix2xy(const t_fmsparse *smat, int ix, int *row, int *col);

/* !\brief Convert a row / col into an array index. This is the index if one
 * considers the matrix as an array.
 * \param smat sparse matrix
 * \param row row index
 * \param col column index
 * \return the array index
 */
int
sm_xy2ix(const t_fmsparse *smat, int row, int col);

#endif
