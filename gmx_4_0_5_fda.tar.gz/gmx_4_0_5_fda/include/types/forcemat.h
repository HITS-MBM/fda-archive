/*
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 4.0
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2004, The GROMACS development team,
 * check out http://www.gromacs.org for more information.

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * GRoups of Organic Molecules in ACtion for Science
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "simple.h"

#ifndef _forcemat_h
#define _forcemat_h

#define FMNO -1

/* This enumeration defines the types of interactions stored in the forcematrix 
 * iNone     - no interaction
 * iBond     - bond stretching
 * iAngle    - angle bending
 * iDihedral - dihedral angles
 * iPolar    - polarizations
 * iLJw      - Lennard Jones (Van der Waals interaction)
 * iCoul     - Coulomb
 * iAll      - all interactions together (used by tools)
*/
enum {
  iNone, iBond, iAngle, iDihedral, iPolar, iLJ, iCoul, iAll
};


typedef struct {
  char		*groupname; /* Name of the group in the index file that contaians the
                             * atoms for which force will be written out. */
  int		writefreq;  /* Number of timesteps the forces are written out */
  int		memsize;
  int		nsteps;	    /* Total number of writes, this is 
			       simulation timesteps / writefreq */ 
  bool          bVariance;  /* Should average forces or variances of forces be calculated? */
  char*         fmfile;     /* Output file for pairwise forces */
  bool          bForce;     /* TRUE if forces should be written out, FALSE if not */
  bool          bWater;     /* Use pair-wise force inner loops for water? */
} t_fmpar;


typedef struct {
  real		*force;   /* Symmetric matrix containing nonbonded forces between atom pairs */
  atom_id       *index;  /* Atom id's of all atoms in the forcematrix */
  char		*interaction; /* Interaction type */
  int		*ncol;   /* Number of columns in each row */

  /* scratch entries are used to efficiently store data until the neighbour-lists
    are updated. This saves a lot of calculation time */
  real		*scratch_force;
  int		*scratch_index;
  char		*scratch_interaction;
  int		*scratch_ncol;

  int		*fmatom_id;  /* Atom id's */
  int           *fmatoms;    /* Mapping between atom_id's and the actual positions of
                               atoms in the forcematrix. The array is of length sysanr;
                               it contains the corresponding rows/columns in the forcematrix 
                               or FMNO if no forces should be written out. 
                               This is mainly for use in the nonbonded kernels.*/
  int		natoms;       /* Dimension of the symmetric forcematrix (equals nrow/ncol)*/
  int		max_col;      /* Maximal number of possible entries in a column */
  int		max_entries;  /* Maximal number of actual entries in a column */
  int		array_size;   /* Length of the force-matrix array. This is natoms * max_col */
  int           sysanr;      /* Number of atoms in the system */
  t_fmpar       *fmpar;
} t_forcemat;


/* Is this used ? */
typedef struct {
  real force;
  char interaction;
} t_fm_entry;


#endif
