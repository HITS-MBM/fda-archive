#!/bin/bash

export GMXPATH=/path/to/gromacs/binaries
export PF2PATH=/path/to/trfda/binary

# generate initial trajectory
${GMXPATH}/grompp -f md.mdp
${GMXPATH}/mdrun

# TRFDA to obtain summed scalar pairwise forces between atoms and residues
${PF2PATH}/mdrun_pf2 -deffnm rerun -s topol.tpr -rerun traj.trr -nt 1 -pfn alagly.ndx -pfi summed_scalar.pfi -pfa summed_scalar.pfa -pfr summed_scalar.pfr
# TRFDA to obtain punctual stress on atoms and residues
${PF2PATH}/mdrun_pf2 -deffnm rerun -s topol.tpr -rerun traj.trr -nt 1 -pfn alagly.ndx -pfi stress.pfi -pfa stress.pfa -pfr stress.pfr

# visualization; assumes that vmd is in PATH
vmd -e summed_scalar_atom.vmd
vmd -e summed_scalar_residue.vmd
vmd -e stress_atom.vmd
vmd -e stress_residue.vmd
