
###########################################################################
#
# Read the compete forcematrix an return the raw data.
# Returns the header and a list containing all raw data blocks
# 
#
###########################################################################
readFMraw <- function(file) {
	warning("this function is inteded for testing and returns raw data only. Use readFM or readFMsparse if you just want to access the data")
	con = file(file)
	# Open the connection in binary mode
	open(con, open = "rb")
	
	# Read the header
	head = readHead(con)
	if (is.null(head))
		return(NULL)

        cat("version groupname writefreq sysanr fmdim\n");
	cat("Version: ", head$version, "\n");
        cat("Groupname: ", head$groupname, "\n");
        cat("Writefreq: ", head$writefreq, "\n");
	cat("nsteps: ", head$nsteps, "\n");
        cat("sysanr: ", head$sysanr, "\n");
        cat("fmdim: ", head$fmdim, "\n");
        cat("intsize: ", head$intsize, "\n");
        cat("realsize: ", head$realsize, "\n");
	

        # Now read the rest...
	blocks = new("list")
        eof = FALSE; i = 0
        while (!eof) {
                block = readBlock(con, head)
		if (is.null(block)) 
			eof = TRUE
		else {
			i = i + 1
			blocks[[i]] = block
		}
	}
        
        close(con);
	res = list()
	res$head = head
	res$blocks = blocks
	return(res)
}


#***************************************************************************
# Read the header from a forcematrix file.
#
# The function assumes that we are already at the beginning of the header,
# indicated by the <begin_block> tag. Call hasMoreBlocks() before 
# calling readBlock to position the stream to the beginning of the first
# block.
#
# Parameters:
# con - an open (!) connection to the input file
#
# Return:
# list containing the elements
# - version	: Version of the forcematrix file
# - groupname	: Name of group in the index file defining the atoms
#		  for which forces are written out
# - sshell	: Solvent shell around the protein
# - writefreq	: How often (nr. of timesteps) are forces written out
# - sysanr	: Total number of atoms in the system
# - fmdim	: Dimension of the square force matrix
# - intsize	: sizeof(int) used while writing the forcematrix
# - realsize	: sizeof(real) used while writing the forcematrix
#
# Autor:
#   Wolfram Stacklies
#   CAS - MPG Partner Institute for Computational Biology
#   Shanghai, P.R. China
# Date: 05/2007
# last update: 08/26/08 - adopt to forcematrix 1.1 format
#
#***************************************************************************
readHead <- function(con) {

        res = list()
	nargs = 8

        # We set the value to 1 if a name was found.
        # This is to check the file for errors.
        visited = array(FALSE, nargs);

        while ( (line = readLines(con, n=1)) != END_BLOCK()) {

		# Check if we reached the EOF, this indicates a broken header
		if (length(line) == 0)
			return(NULL)
		if (line == BEGIN_BLOCK())
			next;

                # Check for the comment character
                if (substr(line, 1, 1) == COMMENT()) {
                        cat(line, "\n")
                        next
		} 
	
                split = unlist(strsplit(line, "=", perl = TRUE))
                name = split[1]
                value = split[2]

                switch (name,
			"version" = {
				res$version = value
                                if (!visited[1]) visited[1] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
				if (as.double(res$version) < 1.1)
					stop("This code can only handle file version > 1.1!")
			},
                        "groupname" = {
				res$groupname = value
                                if (!visited[2]) visited[2] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
                        "writefreq" = {
				res$writefreq = str2int(value)
                                if (!visited[3]) visited[3] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
			"nsteps" = {
				res$nsteps = str2int(value)
                                if (!visited[4]) visited[4] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
                        "sysanr" = {
				res$sysanr = str2int(value)
                                if (!visited[5]) visited[5] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
                        "fmdim" = {
				res$fmdim = str2int(value)
                                if (!visited[6]) visited[6] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
                        "intsize" = {
				res$intsize = str2int(value)
                                if (!visited[7]) visited[7] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
                        "realsize" = {
				res$realsize = str2int(value)
                                if (!visited[8]) visited[8] = TRUE
                                else cat("Warning: double entry: ", name, "\n")
			},
			cat("Skipping unknown entry: ", name, "\n")
		)
        }

        # Check if entries are missing
        if (sum(visited) < nargs)
                cat("Warning: Incomplete header, entries are missing!\n");

	return(res)
}



#***************************************************************************
# Read a binary block from a forcematrix file.
#
# The function assumes that we are already at the beginning of the block,
# indicated by the <begin_block> tag.  
# Important: C starts counting with zero, R with one. To account for that 
# the fmatom_id and nz_index arrays are incremented by one. 
#
# Parameters:
# con - an open (!) connection to the input file
# head - A list containing the header data, as returned by readHead()
#
# Return:
# List containing the elements:
# - iteration	: The block number (timesteps / writefreq)
# - fmatom_id	: Id's of atoms in the forcematrix
# - nz_count	: Number of non-zero entries in the forcematrix
# - nz_index	: Indices of non-zero positions in the forcematrix
# - nz_fvecs	: Non-zero force vectors in the forcematrix
# 
# Autor:
#   Wolfram Stacklies
#   CAS - MPG Partner Institute for Computational Biology
#   Shanghai, P.R. China
# Date: 05/2007
# 
# Modifications
# - 08/26/08 - adapted to forcematrix version 1.1
# - 02/05/09 - removed reading of ascii files
#
#***************************************************************************
readBlock <- function(con, head) {
	res = readBinaryBlock(con, head)
	if (is.null(res)) {
		return(NULL)
	} 

	# C starts counting with zero, but R with 1
        # Gromacs also starts counting with 1, so these now correspond to the
        # Gromacs index file
        res$fmatom_id = res$fmatom_id + 1
        res$nz_index = res$nz_index + 1

	# reading and parsing the strings may consume quite a lot of memory,
	# so we call the garbage collector here
	gc(verbose = FALSE)

	return(res)
}


#***************************************************************************
# Read a binary block from a forcematrix file.
# Sizes of integer and real values are stored in the file header.
#
# This function should not be called directly. Use readBlock() instead!
#
# Parameters:
# con - an open (!) connection to the input file
# head - a list containing information for the header as returned by readHead()
#
# Return:
# List containing the elements:
# - step	: The block number (timesteps / writefreq)
# - fmatom_id	: Id's of atoms in the forcematrix
# - nz_count	: Number of non-zero entries in the forcematrix
# - nz_index	: Indices of non-zero positions in the forcematrix
# - nz_fvecs	: Non-zero force vectors in the forcematrix
# - interaction : Interaction type (bond | angle | dihedral | polar | LJ | Coulomb)
# 
# Autor:
#   Wolfram Stacklies
#   CAS - MPG Partner Institute for Computational Biology
#   Shanghai, P.R. China
# Date: 05/2007
# - last modified 08/26/08 - adapted to forcematrix version 1.1
#
#***************************************************************************
readBinaryBlock <- function(con, head) {
	if (eof(con))
		return(NULL)

	res = list()
	isize = head$intsize
	rsize = head$realsize

        # Read the binary file data
        res$step = readBin(con, what = "int", n = 1, size = isize);
        res$nz_count  = readBin(con, what = "int", n = 1, size = isize);
        res$fmatom_id = readBin(con, what = "int", n = head$fmdim, size = isize);
        res$nz_index  = readBin(con, what = "int", n = res$nz_count, size = isize);
        res$nz_fvecs  = readBin(con, what = "numeric", n = res$nz_count, size = rsize)
	# Interaction is stored as char to save memory
	res$interaction = as.numeric(readBin(con, what = "raw", n = res$nz_count, size = 1))

        # Read the test int, it should be NEW_ENTRY()
        testint = readBin(con, what = "int", n = 1, size = isize);
        if (testint != NEW_ENTRY()) {
                cat("ERROR: File seems to be corrupted!!!!!\n")
		return(NULL)
	}

	return(res)
}

################################################################################
#
# Return True if the eof has been reached, false otherwise
#
################################################################################
eof <- function(con) {
	# Check if we reached the end of file, marked by a binary "EOF"
	eofStr = readBin(con, what = "int", n = 3, size = 1);
	# 69, 79, 70 is ascii for EOF
	if (sum(eofStr == c(69, 79, 70)) == 3) {
		return(TRUE)
	} else {
		seek(con, where = -3, origin = "current", rw = "read")
		return(FALSE)
	}
}
	

#################################################################################
#
# Count the number of blocks in a file. Returns the number of blocks. After
# iterating over all data blocks the file pointer is set back to the original
# position.
# 
# Parameters:
# - con  : open file connection, after executing readHead()
# - head : the header as returned by readHead()
#
# Return:
# - the number of frames in the force-matrix
#
# Autor:
#   Wolfram Stacklies
#   CAS - MPG Partner Institute for Computational Biology
#   Shanghai, P.R. China
# Date: 10/2008
#
################################################################################
countBlocks <- function(con, head) {
	fmdim  = head$fmdim
	isize  = head$intsize
	rsize  = head$realsize
	csize  = 1
	frames = 0
	fstart = seek(con, where = 0, origin = "current", rw = "read")

	while(TRUE) {
		if (eof(con)) {
			seek(con, where = fstart, origin = "start", rw = "read")
			return(frames)
		}
		iter   = readBin(con, what = "int", n = 1, size = isize);
		asize  = readBin(con, what = "int", n = 1, size = isize);
		offset = isize * fmdim + asize * (isize + rsize + csize)
		seek(con, where = offset, origin = "current", rw = "read")

		# Check for possible file corruption
		magicNumber = readBin(con, what = "int", n = 1, size = isize)
		if (magicNumber != NEW_ENTRY()) {
			cat("File corrupted, only counting the first ", frames, " frames\n")
			return(frames)
		}
		frames = frames + 1
	}
}


#
# Jump to the given block
# This function will read until blocknum - 1. Functions continuing to read
# the open connections will start reading block with ID blocknum.
#
jumpToBlock <- function(con, head, blocknum) {
	fmdim  = head$fmdim
	isize  = head$intsize
	rsize  = head$realsize
	csize  = 1
	frames = 0

	while(frames < blocknum) {
		if (eof(con)) {
			stop("Matrix only contains ", frames, " blocks!")
		}
		iter   = readBin(con, what = "int", n = 1, size = isize);
		asize  = readBin(con, what = "int", n = 1, size = isize);
		offset = isize * fmdim + asize * (isize + rsize + csize)
		seek(con, where = offset, origin = "current", rw = "read")

		# Check for possible file corruption
		magicNumber = readBin(con, what = "int", n = 1, size = isize)
		if (magicNumber != NEW_ENTRY()) {
			stop("File corrupted at frame ", frames)
		}
		frames = frames + 1
	}
	return(frames)
}


#
# Count the number of non-zero elements
#
nonZeroElements <- function(con, head, first = 1, last = -1) {
	fmdim   = head$fmdim
	isize   = head$intsize
	rsize   = head$realsize
	csize   = 1
	frames  = 0
	indices = NULL
	fstart = seek(con, where = 0, origin = "current", rw = "read")

	if (first > 1)
		jumpToBlock(con, head, first)

	# loop until eof if no last block is given
	if (last < 0)
		last = Inf
	# first must start with something >= 1
	if (first < 1)
		first = 1

	while(frames <= (last - first)) {
		if (eof(con)) {
			seek(con, where = fstart, origin = "start", rw = "read")
			return(indices)
		}

        	# Read the binary file data
	        iter = readBin(con, what = "int", n = 1, size = isize);
        	nz_count  = readBin(con, what = "int", n = 1, size = isize);
	        readBin(con, what = "int", n = fmdim, size = isize);
        	nz_index  = readBin(con, what = "int", n = nz_count, size = isize);
		offset = nz_count * (rsize + csize)
		seek(con, where = offset, origin = "current", rw = "read")

		# Check for possible file corruption
		magicNumber = readBin(con, what = "int", n = 1, size = isize)
		if (magicNumber != NEW_ENTRY()) {
			cat("File corrupted, only counting the first ", frames, " frames\n")
			seek(con, where = fstart, origin = "start", rw = "read")
			return(indices)
		}
		frames = frames + 1
		indices = unique(c(indices, nz_index+1))
	}

	# Set file-pointer back to start and return the non-zero indices
	seek(con, where = fstart, origin = "start", rw = "read")
	return(indices)
}



#**********************************************************************
# Check if there are more blocks in the file.
# The function positions the buffer just after the
# '<begin_block>' statement.
# Do not use before reading binary blocks!
#
# Autor:
#   Wolfram Stacklies
#   CAS - MPG Partner Institute for Computational Biology
#   Shanghai, P.R. China
# Date: 05/2007
#
#**********************************************************************
hasMoreBlocks <- function(con) {
	beginBlock = "<begin_block>"

	# Move to the beginning of the next block
	line = readLines(con, n = 1)
	# length(line) == 0 indicates the end of the file
	if (length(line) == 0)
		return(FALSE)
	while (line != beginBlock) {
		if (length(line) == 0)
			return(FALSE)
		line = readLines(con, n = 1);
	}
	return(TRUE)
}



#*********************************************************************
# Convert a string array to integer
#*********************************************************************
str2int <- function(str) {
	res = as.integer(unlist(strsplit(str, "\t")))
	return(res)
}

#*********************************************************************
# Convert a string array to double
#*********************************************************************
str2double <- function(str) {
	res = as.double(unlist(strsplit(str, "\t")))
	return(res)
}



#******************************************************************
# Unpack a force matrix stored as index and vector array.
# Returns a matrix of dimension fmdim X fmdim 
#
# Value:
# - head : header as read by readHead()
# - block : a data block as read by readBlock()
# - interaction : The kind of interaction to read from the
#		  forcematrix. See definitions.R for details.
#
# Return:
# - a matrix of dimensions fmdim X fmdim
#
# Changes:
# 02/06/2009: Adopted the metod to be able to read the older 1.1
#             as well as the new 1.2 force matrix file format
#
#******************************************************************
unpackMatrix <- function(head, block, itype, symm=TRUE, as.array=FALSE) {

	iALL  = 8

	# Create the matrix.
	fmdim = head$fmdim
	# Two dimensional matrix
	force       = array(0, dim = fmdim * fmdim)

	# The forcemat format slightly changed from version 1.1 to 1.2. 
	# In 1.1 bonded forces are stored symetrically, what means i,j = j,i. In 1.2 this was
	# changed such that either i,j or j,i is stored.
	if (head$version == "1.1" && symm) {
		cond = c(which(block$interaction == 1),
			 which(block$interaction == 2),
			 which(block$interaction == 3))
		if (length(cond) > 0)
			block$nz_fvecs[cond] = block$nz_fvecs[cond] / 2
	}

	if (!itype[iALL]) {
		ix = which(itype == TRUE)
		if (length(ix) == 0)
			stop("You must specify at least one interaction type\n")
		for (i in 1:length(ix)) {
			cond = which(block$interaction == (ix[i]-1))
			force[block$nz_index[cond]] = block$nz_fvecs[cond]
		}
	} else 
		force[block$nz_index]       = block$nz_fvecs

	force       = matrix(force, nrow = head$fmdim, ncol = head$fmdim)
	# make matrix symmetric
	if (symm)
		force       = force + t(force)

	if (as.array)
		return(matrix(force, ncol=fmdim * fmdim))
	else
		return(force)
}


###################################################################################
#
# Read a force matrix file into a NxNxT matrix, where N is the number of
# of force atoms, and T the number of frames. This will provide fastest
# access but also consume most memory. Be aware that the required memory
# space grows with the square of the number of atoms!
#
# Value:
# - file : force-matrix file to read
# - atoms: sum forces over atoms (column sum)
# - itype: the interaction type (iBOND, iANGLE...)
# - symm: make the force matrix symmetric. This will add coulomb and VDW
#   forces (if any)
# 
# Return:
# - a list of forcematrices, one entry for each frame read from the data 
#
###################################################################################
readFM <- function(file, sum = FALSE, itype = "all", symm=TRUE) {

	itype = interactions(itype)

	con = file(file, open="rb")
        # Read the header
        if (hasMoreBlocks(con))
                head = readHead(con);
	# Count blocks
	nframes = countBlocks(con, head)
	cat("  Matrix contains", nframes, "blocks\n")

        # Now read the rest...
	if (sum)
		force = array(0.0, dim = c(head$fmdim, nframes))
	else {
		force = array(0.0, dim = c(head$fmdim, head$fmdim, nframes))
	}

        eof = FALSE; ix = 1
        while (!eof && ix <= nframes) {
		cat(".")
                block = readBlock(con, head)
		eof = eof(con)
		if (sum) {
			force[,ix] = apply(abs(unpackMatrix(head, block, itype = itype, TRUE)), 2, sum)
		} else {
			force[,,ix] = unpackMatrix(head, block, itype = itype, symm)
		}
		ix = ix + 1
        }
	cat("\n")

        close(con);
	attr(force, "fmatom_id") = as.numeric(block$fmatom_id)
        return(force)
}


###################################################################################
#
# Read a force matrix file into a single matrix of dimension (N*N)xT. 
# This format is useful when performing PCA.
# This will provide fastest access but also consume most memory. Be aware that the 
# space grows with the square of the number of atoms!
#
# Value:
# - file : force-matrix file to read
# - what: what to read (in case of a force trajectory containing the norm, distances
#         and x, y, z components)
# - cutoff: remove all columns from the matrix with average value below the cutoff
# - itype: the interaction type (iBOND, iANGLE...)
# 
# Return:
# - a list of forcematrices, one entry for each frame read from the data 
#
###################################################################################
readFMpca <- function(file, what = "norm", cutoff = 1) {

	what  = trj_type(what)

	con = file(file, open="rb")
        # Read the header
        if (hasMoreBlocks(con))
                head = readHead(con);
	# Count blocks
	cat("\ncounting blocks...")
	nframes = countBlocks(con, head)
	cat("  -> Matrix contains", nframes, "blocks\n")

        # Now read the rest...

        eof = FALSE; 
	type = 1;

	# Read either the norm, the x, y, z component or COM distances
	stop = what * nframes / 5
	start = (what - 1) * nframes / 5 + 1

	cat("Determining amount of memory needed...  ")
	pair_ix = nonZeroElements(con, head, first = start, last = stop)
	mb = round(length(pair_ix) * nframes / 5 * 4 / 1048576)
	cat("-> need", length(pair_ix), "x", nframes / 5, "bytes (", mb, " MB )\n")
	cat("Moving to frame ", start, ", this can take a little...\n")
	jumpToBlock(con, head, start)
	cat("Allocating memory for a ", nframes / 5, "x", length(pair_ix), " matrix\n")
	force = array(0.0, dim = c(nframes / 5, length(pair_ix)))
	cat("\n")

	ix = 1
        while (!eof && ix <= nframes && ix <= nframes / 5) {
                block = readBlock(con, head)
		eof = eof(con)
		cat("\rreading block", ix+start-1, " ")
		mpos = which((pair_ix %in% block$nz_index) == TRUE)
		force[ix, mpos] = block$nz_fvecs 
		ix = ix + 1
        }
	cat("\n")

        close(con);
	attr(force, "fmatom_id") = as.numeric(block$fmatom_id)
	
	# Create and assign row / column names
	if (!is.na(cutoff)) {
		cat("\nCalculating column names and removing empty columns with mean < ", cutoff, "... ")
	} else {
		cat("\nCalculating column names... ")
	}
	rownames(force) = 1:(nframes / 5)
	colnames = array("0", ncol(force))
	indexarray = matrix(0, nrow = 2, ncol = ncol(force))
	for (i in 1:ncol(force)) {
		xy = ix2xy(pair_ix[i], head$fmdim)
		colnames[i] = paste(xy[1], ".", xy[2], sep="")
		indexarray[, i] = xy
	}
	colnames(force) = colnames
	cat("done\n\n")

	if (!is.na(cutoff)) {
		cond = apply(abs(force), 2, mean) >= cutoff
		force = force[, cond]
		attr(force, "indexarray") = indexarray[, cond]
	} else {
		attr(force, "indexarray") = indexarray
	}

	# Garbage collection
	gc(verbose = FALSE)
		
        return(force)
}


######################################################################
#
# Read a force matrix file into a sparse data structure.
# This will save tons of memory and provide reasonable fast accces.
# The data structure is a vector of vectors of vectors. (Mabye it's
# easier to think in dimensions, it is fmdim X fmdim X nframes where
# fmdim is the dimension of each force-matrix frame and nframes the
# total number of frames we have.
# If an entry is empty (two atoms that do not see each other) this field
# is left NULL.
# Use smget() to acces the elements.
#
# Value:
# - file : force-matrix file to read
#
# Return:
# - the data structure as described above
#
######################################################################
readFMsparse <- function(file, itype = "all", symm = TRUE) {

	itype = interactions(itype)

        con = file(file, open="rb")
        # Read the header
        if (hasMoreBlocks(con))
                head = readHead(con);
	# Count blocks
	nframes = countBlocks(con, head)
	cat("  Matrix contains", nframes, "blocks\n")

	frames = list()
        eof = FALSE; 
	iteration = 1
        while (!eof) {
		cat(".")
                block = readBlock(con, head)
		eof = eof(con)
		# Create a sparse matrix
		frames[[iteration]] = 
			as.matrix.csr(unpackMatrix(head, block, itype = itype, symm=symm))
		iteration = iteration + 1
        }
	cat("\n")
        close(con);
        return(frames)
}


################################################################################
# Read only a subset of a force matrix
# This will only read the given atoms from the force matrix.
#
################################################################################
readFMpart <- function(file, atoms = NULL, symm=TRUE) {
	# This is a helper function used in the apply call below
	getix <- function(x) {
		pos = which(block$nz_index == x)
		if (length(pos) == 0)
			return(0.0)
		else
			return(block$nz_fvecs[pos])
	}

	if (is.null(atoms) || length(atoms) == 1)
		stop("No or only a single atom given\n");

        con = file(file, open="rb")
        # Read the header
        if (hasMoreBlocks(con))
                head = readHead(con);
	# Count blocks
	nframes = countBlocks(con, head)
	cat("  Matrix contains", nframes, "blocks\n")
	fmdim = head$fmdim

	len   = length(atoms)
	force = array(0.0, dim = c(len^2, nframes))
	ix    = matrix(0, nrow = len * len, ncol = 1)
	pos   = 1
	for (i in atoms) {
		for (j in atoms) {
			ix[pos, 1] = (i-1) * fmdim + j
			pos = pos + 1
		}
	}

        eof = FALSE; iteration = 1
        while (!eof) {
		cat(".")
                block = readBlock(con, head)
		eof = eof(con)
		force[,iteration] = apply(ix, 1, getix)
		iteration = iteration + 1
        }
	cat("\n")
        close(con);

	force = array(force, dim = c(len, len, nframes), dimnames = list(atoms, atoms, NULL))
	# Make the matrix symmetric
	if (symm)
		force = force + aperm(force, perm=c(2,1,3))
        return(force)
}


#
# Get a vector from the sparse matrix
#
smxy <- function(fmat, i, j) {
	val = fmat[[i]][[j]]
	if (is.null(val))
		return(NULL)
	else
		return(array(fmat[[i]][[j]]))
}

smix <- function(fmat, ix) {
	ix = ix2xy(ix, length(fmat))
	val = fmat[[ ix[1] ]] [[ ix[2] ]]
	if (is.null(val))
		return(NULL)
	else
		return(array(val))
}


