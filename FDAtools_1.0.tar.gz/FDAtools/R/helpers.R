
#
# This parses an array of given interactions
#
interactions <- function(input) {

	itypes = c("none", "bond", "angle", "dihedral", "polar", "vdw", "coulomb", "all")
	interaction = array(FALSE, 8)

	for (i in 1:length(input)) {
		ix = which(itypes == input[i])
		if (length(ix) == 0)
			stop(input[i], " Not a valid interaction type!")
		interaction[ix] = TRUE
	}
	if (sum(interaction) == 0)
		stop("At least one interaction must be given")

	return(interaction)
}


#
# This parses an array of given trajectory intervals
#
trj_type <- function(input) {
	types = c("norm", "xx", "yy", "zz", "dist")
	match.arg(input, types)
	
	return(which(types == input))
}


BEGIN_BLOCK <- function() {
	return("<begin_block>")
}

END_BLOCK <- function() {
	return("<end_block>")
}

COMMENT <- function() {
	return(";")
}

NEW_ENTRY <- function() {
	return(-280480)
}

