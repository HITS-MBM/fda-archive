
#
# Convert an array index to an (x,y) position
#
ix2xy <- function(index, fmdim) {
        x = ceiling(index / fmdim)
        y = index %% fmdim
        if (y == 0)
                y = fmdim
        return( c(x,y) )
}


#
# Convert an (x,y) value to an array index
#
xy2ix <- function(row, col, fmdim) {
        return((row-1) * fmdim + col)
}


#
# Return a vector containing the amino acid 3-letter codes
#
AAtriplets <- function() {
	t = vector(mode = "character", length = 20)
	t[1]  = "ALA" # A
	t[2]  = "CYS" # C
	t[3]  = "ASP" # D
	t[4]  = "GLU" # E
	t[5]  = "PHE" # F
	t[6]  = "GLY" # G
	t[7]  = "HIS" # H
	t[8]  = "ILE" # I
	t[9]  = "LYS" # K
	t[10] = "LEU" # L
	t[11] = "MET" # M
	t[12] = "ASN" # N
	t[13] = "PRO" # P
	t[14] = "GLN" # Q
	t[15] = "ARG" # R
	t[16] = "SER" # S
	t[17] = "THR" # T
	t[18] = "VAL" # V
	t[19] = "TRP" # W
	t[20] = "TYR" # Y

	t[21] = "DA" # DNA Adenine
	t[22] = "DT" # DNA Thymine
	t[23] = "DG" # DNA Guanine
	t[24] = "DC" # DNA Cystosine

	return(t)
}

#
# Return a vector containing the amino acid one letter code, 
# including the gap character at pos 21	
#
aAcids <- function() {
        aacid = vector(mode = "character", length = 25)
        aacid[1] = "A"          # Alanine (Ala)
        aacid[2] = "C"          # Cysteine (Cys)
        aacid[3] = "D"          # Aspartic acid (Asp)
        aacid[4] = "E"          # Glutamic Acid (Glu)
        aacid[5] = "F"          # Phenylalanine (Phe)
        aacid[6] = "G"          # Glycine (Gly)
        aacid[7] = "H"          # Histidine (His)
        aacid[8] = "I"          # Isoleucine (Ile)
        aacid[9] = "K"          # Lysine (Lys)
        aacid[10] = "L"         # Leucine (Leu)
        aacid[11] = "M"         # Methionine (Met)
        aacid[12] = "N"         # Asparagine (Asn)
        aacid[13] = "P"         # Proline (Pro)
        aacid[14] = "Q"         # Glutamine (Gln)
        aacid[15] = "R"         # Arginine (Arg)
        aacid[16] = "S"         # Serine (Ser)
        aacid[17] = "T"         # Theronine (Thr)
        aacid[18] = "V"         # Valine (Val)
        aacid[19] = "W"         # Tryptophan (Trp)
        aacid[20] = "Y"         # Tyrosine (Tyr)

	aacid[21] = "dA"	# Adenine
	aacid[22] = "dT"	# Thymine
	aacid[23] = "dG"	# Guanine
	aacid[24] = "dC"	# Cytosine

        aacid[25] = "-"         # Alignment gap

        return(aacid)
}


#
# Convert amino acid 3-letter representation to single character
# representation.
#
aa3to1 <- function(triplets) {
	aa1 = aAcids()
	aa3 = AAtriplets()

	res = array("X", length(triplets))
	for(i in 1:length(triplets)) {
		pos = which(aa3 == triplets[i])
		if (length(pos) == 0)
			stop("Unknown residue: ", triplets[i])
		res[i] = aa1[which(aa3 == triplets[i])]
	}

	return(res)
}		


#
# Convert amino acid single character representation to 3-letter
# representation.
#
aa1to3 <- function(letters) {
	aa1 = aAcids()
	aa3 = AAtriplets()
	
	res = array("XXX", length(letters))
	for(i in 1:length(letters))
		res[i] = aa3[which(aa1 == letters[i])]

	return(res)
}


#
# Return the amino acid sequence (as char array) of the given pdb file
#
aaSequence <- function(pdb) {
        # Count the residues. Do not trust the SEQRES record!
        resno = as.integer(pdb$atom[, "resno"])
        prevRes = -1; pos = 1; resCount = 0;
	seq = NULL
	firstAtoms = NULL
        for (i in 1:length(resno)) {
                currRes = resno[i]
                if (currRes > prevRes) {
                        # Jupp, we found a new residue...
                        resCount = resCount + 1
                        prevRes = currRes
			seq[pos] = aa3to1(pdb$atom[i, "resid"])
			firstAtoms[pos] = i
			pos=pos+1
                }
        }
	cat("Found ", resCount, " residues\n")
	attr(seq, "index") = firstAtoms
	return(seq)
}


#
# Calculate residue averages for the given b-factors and return
# an array as input for write.pdb	
#
bfColor <- function(pdb, bf) {
	colors = array(0.0, length(bf))
	resno = unique(pdb$atom[, "resno"])
	for (i in resno) {
		ix = which(pdb$atom[, "resno"] == i)
		col = mean(bf[ix])
		colors[ix] = col
	}
	return(colors)
}


#
# This function takes residue averages and preparse them as an array
# as input for write.pdb.
# Note: The residue number in pdb files may start from anywhere
# and may not be contignuous!
#
bfColorRes <- function(pdb, bf) {
	colors = array(0.0, length(pdb$atom[,1]))
	resno = unique(pdb$atom[, "resno"])
	stop = 0
	pos = 1
	for (i in resno) {
		ix = which(pdb$atom[, "resno"] == i)
		start = stop + 1
		stop = start + length(ix) - 1
		colors[start:stop] = bf[pos]
		pos = pos + 1
	}
	return(colors)
}


#
# calculate the residue averages from the given atom-wise b-factors
#
resAverage <- function(pdb, bf) {
	resno = unique(pdb$atom[, "resno"])
	colors = array(0.0, length(resno))
	for (i in 1:length(resno)) {
		ix = which(pdb$atom[, "resno"] == resno[i])
		col = mean(bf[ix])
		colors[i] = col
	}
	return(colors)
}



#
# Simple helper to calculate the euclidic norm of a vector
#
vnorm <- function(vector) {
	return( sqrt(sum(vector^2)))
}


#
# Extracts the eigenvectors from a gromacs - xtc file (generated by g_anaeig)
# Returns a matrix with eigenvectors as columns
#
readEvec <- function(file) {
	tmp = as.matrix(read.table(file, comment.char = "@", na.strings="&", fill=TRUE))
	seperators = which(is.na(tmp[,2]))
	natoms = seperators[1]-1
	nvecs = length(seperators) / 4
	tmp = tmp[-seperators, ]
	
	vectors = matrix(0, nrow = natoms, ncol = nvecs)

	for (i in 0:(nvecs-1)) {
		ix = 1+(i*4*natoms)
		vectors[,(i+1)] = tmp[ix:(ix+natoms-1), 2]
	}
	
	return(vectors)
}



