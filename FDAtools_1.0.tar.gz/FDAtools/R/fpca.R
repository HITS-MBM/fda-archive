
#
# This will perform fpca on the given input file.
# ev can be any number of eigenvectors, e.g c(1,2,3)
#
fpca <- function(file, cutoff = 1) {
	mat.norm = readFMpca(file=file, what="norm", cutoff=NA)
	mat.xx   = readFMpca(file=file, what="xx", cutoff=NA)
	mat.yy   = readFMpca(file=file, what="yy", cutoff=NA)
	mat.zz   = readFMpca(file=file, what="zz", cutoff=NA)

	mean.xx = which(apply(abs(mat.xx), 2, mean) >= cutoff)
	mean.yy = which(apply(abs(mat.yy), 2, mean) >= cutoff)
	mean.zz = which(apply(abs(mat.zz), 2, mean) >= cutoff)
	include = unique(c(mean.xx, mean.yy, mean.zz))
	mat.norm = mat.norm[, include]
	attr(mat.norm, "indexarray") = attr(mat.xx, "indexarray")[, include]

	pc.xx = prcomp(mat.xx[, include])
	pc.yy = prcomp(mat.yy[, include])
	pc.zz = prcomp(mat.zz[, include])

	res = list()
	res$xx = pc.xx
	res$yy = pc.yy
	res$zz = pc.zz
	res$force = mat.norm

	return(res)
}


#
# Calculated a cumulative eigenvector. This is the sum of the given
# eigenvectors of the x, y, z components.
# Afterwards the norm for all (x, y, z) triplets is calculated and returned.
#
cumulativeEv <- function(fpcaRes, ev=1) {
	evmat = matrix(0, nrow(fpcaRes$xx$rotation), 3)

	evmat[,1] = apply(fpcaRes$xx$rotation[,ev, drop=FALSE], 1, sum)
	evmat[,2] = apply(fpcaRes$yy$rotation[,ev, drop=FALSE], 1, sum)
	evmat[,3] = apply(fpcaRes$zz$rotation[,ev, drop=FALSE], 1, sum)
	ev.norm = apply(evmat, 1, vnorm)

	return(ev.norm)
}

