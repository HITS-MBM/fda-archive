
#
# Returns the contents written to the file.
# Creates on dummy atom at the COM of each residue.
# Connects atoms with correlation value > threshold in the coupling
# matrix.
#

resGraph <- function(pdb, force, cutoff, file) {

	if (sum(abs(force - t(force))) != 0)
		stop("Input matrix is not symmetric!")

	matching = unique(as.numeric(pdb$atom[,"resno"]))
	filename = strsplit(file, ".pdb", fixed=TRUE)
	comFile  = paste(filename, "_com.pdb", collapse="", sep="")
	edgeFile = paste(filename, "_edge.pdb", collapse="", sep="")
	diag(force) = 0

	ddE = apply(abs(force), 2, sum)
	ddE = ddE / max(ddE)

	# The length of the pdb file entries (in characters)
	pdbFileChars = 76
	mdim = ncol(force)

	# coords will contain the average coordinates of each residue
	coords = matrix(0, 1, 3 * length(matching))
	# resIds will contain resId and resno
	resIds = matrix("-", length(matching), 2)

	bFactorsCom = array(0, length(matching))
	resPos = 1
	for (res in matching) {
		# ids contains all atoms, that belong to the residue, which is now stored in res
		ids = which(pdb$atom[, "resno"] == paste(res))

		# Taking C alpha coordinates as ends of the edges if residue has a C alpha atom
		hasCalpha = as.double(pdb$atom[pdb$calpha, "x"][res])
		coords[3 * resPos - 2] = ifelse(is.na(hasCalpha), mean(as.double(pdb$atom[ids, "x"])), hasCalpha)
		hasCalpha = as.double(pdb$atom[pdb$calpha, "y"][res])
                coords[3 * resPos - 1] = ifelse(is.na(hasCalpha), mean(as.double(pdb$atom[ids, "y"])), hasCalpha)
                hasCalpha = as.double(pdb$atom[pdb$calpha, "z"][res])
                coords[3 * resPos] = ifelse(is.na(hasCalpha), mean(as.double(pdb$atom[ids, "z"])), hasCalpha)
		# If we do not want the C alpha atoms as ends of the edges, we might use this:
		## Average coordinates
		#coords[3 * resPos - 2] = mean(as.double(pdb$atom[ids, "x"]))
		#coords[3 * resPos - 1] = mean(as.double(pdb$atom[ids, "y"]))
		#coords[3 * resPos] = mean(as.double(pdb$atom[ids, "z"]))

		resIds[resPos, 1:2] = pdb$atom[ids[1], c("resid", "resno")]

		# Assign b-factors according to ddE value
		bpos = which(matching == res)
		if (bpos > nrow(force))
			bpos = bpos - nrow(force)
		if (length(bpos) > 0) {
			bFactorsCom[resPos] = ddE[bpos]
		}
		resPos = resPos + 1
	}


	# Now write a pdb file containing only C atoms at center of mass of
	# the residues
	bf = bFactorsCom
	write.pdb(file=comFile, xyz=coords, resno=resIds[,2], resid=resIds[,1], 
	          elety=array("C", length(matching)), het=FALSE, 
		  b = bf, verbose=TRUE)

	# Get the written data back (this is kind of a workaround)
	entries = read.fwf(comFile, pdbFileChars)
	contentsCom = as.matrix(entries)
	# Cut the "END" and "TER" lines
	contentsCom = contentsCom[1:(length(contentsCom) - 2)]
	arrayPos = length(contentsCom)
	include = array(FALSE, mdim)

	# Variables for edge graph
	num = sum(abs(force) >= cutoff)
	xyz    = array(0, 3*num)
	bf     = array(0, num)
	atype  = array(0, num)
	resno  = array(0, num)
	atomNo = 0
	contentsEdge = array(paste(array(" ", pdbFileChars), collapse=""), num/2)

	for(i in 1:(mdim-1)) {
		for(j in (i+1):mdim) {
			if (abs(force[i,j]) >= cutoff) {
				#
				# Edge graph
				#
				
				range = (3*atomNo + 1):(3*atomNo+6)
				xyz[range]= c(coords[(3*i-2):(3*i)], coords[(3*j-2):(3*j)])
				atomNo = atomNo + 2;
				bf[c(atomNo - 1, atomNo)] = force[i,j]
				atype[c(atomNo - 1, atomNo)] = "H"
				resno[atomNo - 1] = i
				resno[atomNo]     = j

                                if (atomNo - 1 < 10)         blancs =  "    "
                                else if (atomNo - 1 < 100)   blancs =  "   "
                                else if (atomNo - 1 < 1000)  blancs =  "  "
                                else if (atomNo - 1 < 10000) blancs =  " "
                                else if (atomNo - 1 < 100000) blancs = ""
                                else stop("Number too large for pdb file. Too many atoms...\n")
                                string = paste("CONECT", atomNo - 1, blancs, atomNo, sep="")
                                contentsEdge[atomNo / 2] = paste(string, paste(array(" ", pdbFileChars -
                                                     nchar(string)), collapse=""), sep = "")


				#
				# COM graph
				#
				arrayPos = arrayPos+1
				if (i < 10) blancs = "   "
				else if (i < 100) blancs = "  "
				else if (i < 1000) blancs = " "
				else if (i < 10000) blancs = ""
				else stop("Too many atoms for pdb file.\n")
				string = paste("CONECT ", i, blancs, j, sep="")
				contentsCom[arrayPos] = paste(string, paste(array(" ", pdbFileChars -
					nchar(string)), collapse=""), sep = "")

				include[c(i, j)]=TRUE
			}
		}
	}
	# Write the COM graph
	if (sum(include) < mdim)
		contentsCom=contentsCom[-(which(include==FALSE))]
	contentsCom[length(contentsCom) + 1] = "TER   "
	contentsCom[length(contentsCom) + 1] = "END"
	write(file=comFile, contentsCom)

        write.pdb(xyz = as.vector(xyz), file = edgeFile, b=bf, elety=atype, resno=resno)
        entries = read.fwf(edgeFile, pdbFileChars)
        lines = levels(entries[1,])
        # Cut the "END" and "TER" lines
        lines = lines[1:(length(lines) - 2)]

        contentsEdge[atomNo / 2 + 1] = "TER   "
        contentsEdge[atomNo / 2 + 2] = "END"
        write(file=edgeFile, lines, append = FALSE)
	write(file=edgeFile, contentsEdge, append = TRUE)

}



asciiGraph <- function(pdb, force, cutoff, sep="+", matching=NA) {
	if (length(matching) == 1)
		matching = unique(as.numeric(pdb$atom[,"resno"]))

	temp = 1:length(matching)
	resnames = paste(apply(matrix(aaSequence(pdb)), 1, aa1to3), 
			 as.character(temp[matching != 0]), sep="_")

	edges = matrix(FALSE, nrow = nrow(force), ncol=ncol(force))
	edges[abs(force) >= cutoff] = TRUE

	resid = 1
	for (resid in 1:length(resnames)) {
		if (sum(edges[, resid]) > 0) {
			cat(resnames[resid])
			cat(" -> ")
			cat(resnames[edges[, resid]], sep=sep)
			cat("\n")
		}
		resid = resid + 1
	}
}


