
#
# Returns the contents written to the file.
# Creates on dummy atom at the COM of each residue.
# Connects atoms with correlation value > threshold in the coupling
# matrix.
#
pcaGraph <- function(pdb, cutoff, force, evec, file, col = "ev") {

	# Check input values
	types = c("force", "ev")
	match.arg(col, types)
	if (length(evec) != ncol(force))
		stop("evec must have the same length as ncol(force)")
	names = colnames(force)	

	# Create the edge array
	edges = attr(force, "indexarray")
	if(is.null(edges))
		stop("force must be a force matrix created by readFMpca!")
	edges = edges[, abs(evec) >= cutoff]

	if (col == "force")
		avg_force = apply(abs(force), 2, mean)

	# The length of the pdb file entries (in characters)
	pdbFileChars = 76

	# coords will contain the average coordinates of each residue
	residues = as.numeric(unique(pdb$atom[, "resno"])) 
	nres   = length(residues)
	coords = matrix(0, 1, 3 * nres)

	resPos = 1
	for (res in residues) {
		ids = which(pdb$atom[, "resno"] == paste(res))
		# Average coordinates
		coords[3 * resPos - 2] = mean(as.double(pdb$atom[ids, c("x")]))
		coords[3 * resPos - 1] = mean(as.double(pdb$atom[ids, c("y")]))
		coords[3 * resPos] = mean(as.double(pdb$atom[ids, c("z")]))

		resPos = resPos + 1
	}
	include = array(FALSE, nres)

	# Variables for edge graph
	num = 2 * ncol(edges)
	xyz    = array(0, 3*num)
	bf     = array(0, num)
	atype  = array(0, num)
	resno  = array(0, num)
	atomNo = 0
	contentsEdge = array(paste(array(" ", pdbFileChars), collapse=""), num/2)

	for(i in 1:ncol(edges)) {
		range = (3*atomNo + 1):(3*atomNo+6)
		x = which(residues == residues[edges[1, i]])
		y = which(residues == residues[edges[2, i]])
		xyz[range]= c(coords[(3*x-2):(3*x)], coords[(3*y-2):(3*y)])
		atomNo = atomNo + 2;
	
		# Assign b-factors
		name = paste(x, ".", y, sep="")
		if (col == "force")
			bf[c(atomNo - 1, atomNo)] = avg_force[which(names == name)]
		else
			bf[c(atomNo - 1, atomNo)] = abs(evec[which(names == name)])

		atype[c(atomNo - 1, atomNo)] = "H"
		resno[atomNo - 1] = edges[1, i]
		resno[atomNo]     = edges[2, i]

                if (atomNo - 1 < 10)         blancs = "    "
                else if (atomNo - 1 < 100)   blancs = "   "
                else if (atomNo - 1 < 1000)  blancs = "  "
                else if (atomNo - 1 < 10000) blancs = " "
                else stop("Number too large for pdb file. Too many atoms...\n")
               	string = paste("CONECT", atomNo - 1, blancs, atomNo, sep="")
               	contentsEdge[atomNo / 2] = paste(string, paste(array(" ", pdbFileChars -
                               	             nchar(string)), collapse=""), sep = "")
		include[i]=TRUE
	}
        write.pdb(xyz = as.vector(xyz), file = file, elety=atype, resno=resno, b=bf)
        entries = read.fwf(file, pdbFileChars)
        lines = levels(entries[1,])
        # Cut the "END" and "TER" lines
        lines = lines[1:(length(lines) - 2)]

        contentsEdge[atomNo / 2 + 1] = "TER   "
        contentsEdge[atomNo / 2 + 2] = "END"
        write(file=file, lines, append = FALSE)
	write(file=file, contentsEdge, append = TRUE)

}

