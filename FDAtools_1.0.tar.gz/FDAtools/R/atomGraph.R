#############################################################
# pdb       - pdb file with original coordinates
# edges     - matrix with pairwise forces
# cutuff    - cutoff for drawing an edge
# file  - file of the output pdb file
# abs       - use absolute values for cutoff
# indexfile - name of an indexfile giving the atoms to draw
#             edges between
# Residue numbers are the original atom indices
#############################################################

atomGraph <- function(pdb, edges, cutoff, file, abs=TRUE, indexfile=NULL) {

	# The length of the pdb file entries (in characters)
	pdbFileChars = 76

	if (!is.null(indexfile)) {
		index = array(FALSE, length(pdb$atom[,1]))
		ix = read.delim(indexfile, header=FALSE, sep=" ", comment.char="[")
		cond = !is.na(ix)
		ix = ix[cond]
		index[unique(ix)] = TRUE
	}

	if (abs) { num = sum(abs(edges) >= abs(cutoff)) }
	else {
		if (cutoff > 0) { num = sum(edges >= cutoff) }
		else { num = sum(edges <= cutoff) }
	}
	xyz    = array(0, 6*num)
	bf     = array(0, 2*num)
	atype  = array(0, 2*num)
	resno  = array(0, 2*num)
	atomNo = 0
	contents = array(paste(array(" ", pdbFileChars), collapse=""), num)

	mdim = nrow(edges)
	addEdge = FALSE
	for (i in 1:mdim) {
		# cat("Row number: ", i, "\n")
		if (!is.null(indexfile) && !index[i])
			next
		for (j in 1:mdim) {
			if (!is.null(indexfile) && !index[j])
				next
			if (abs) {
				if (abs(edges[i,j]) >= abs(cutoff)) { addEdge = TRUE }
				else { addEdge = FALSE }
			} else {
				# Check if we want repulsive or attractive interactions
				if (cutoff > 0) {
					if (edges[i,j] >= cutoff) { addEdge = TRUE }
					else { addEdge = FALSE }
				} else if (cutoff < 0) {
					if (edges[i,j] <= cutoff) { addEdge = TRUE }
					else { addEdge = FALSE }
				} else {
					addEdge = FALSE
				}
			}

			if (addEdge) {
				# add two new atoms
				range = (3*atomNo + 1):(3*atomNo+6)
				xyz[range] = c(as.numeric(pdb$atom[i, c("x","y","z")]),
					       as.numeric(pdb$atom[j, c("x","y","z")]))
				atomNo = atomNo + 2;
				bf[c(atomNo - 1, atomNo)] = edges[i,j]
				atype[c(atomNo - 1, atomNo)] = "H"
				resno[atomNo - 1] = i
				resno[atomNo]     = j

				if (atomNo - 1 < 10)          blancs = "    "
				else if (atomNo - 1 < 100)    blancs = "   "
				else if (atomNo - 1 < 1000)   blancs = "  "
				else if (atomNo - 1 < 10000)  blancs = " "
				else if (atomNo - 1 < 100000) blancs = ""
				else if (atomNo >= 100000)
					stop("Number too large for pdb file. Too many atoms...\n")
				string = paste("CONECT", atomNo - 1, blancs, atomNo, sep="")
				contents[atomNo / 2] = paste(string, paste(array(" ", pdbFileChars -
						     nchar(string)), collapse=""), sep = "")
			}
		}
	}
	
	# Remove unnecessarily allocated space 
	xyz   = xyz[1:(3*atomNo)]
	bf    = bf[1:atomNo]
	atype = atype[1:atomNo]
	resno = resno[1:atomNo]
	sig = sign(bf)
	bf = log(abs(bf)+1)*sig
	# scale both, negative and poitive b-factors to be between 0 and 1
	cat("max(bf) ", max(bf), " - min(bf) ", min(bf), "\n")
	cond = bf > 0
	bf[cond] = bf[cond] / max(bf)
	bf[!cond] = bf[!cond] / abs(min(bf))
	write.pdb(xyz = as.vector(xyz), file = file, b=bf, elety=atype, resno=resno);
	entries = read.fwf(file, pdbFileChars)
	lines = levels(entries[1,])
	# Cut the "END" and "TER" lines
	lines = lines[1:(length(lines) - 2)]

	contents[atomNo / 2 + 1] = "TER   "
	contents[atomNo / 2 + 2] = "END"
	write(file=file, lines, append = FALSE)
	write(file=file, contents, append = TRUE)
}



##########################################################################
#
# Write a set of edges to a pdb file.
# Edges can optionally be colored with the given b-factors.
#
##########################################################################

pdbEdges <- function(pdb, pairs, weights=NULL, file) {

	# The length of the pdb file entries (in characters)
	pdbFileChars = 76

	if (!is.matrix(pairs) || ncol(pairs) != 2) {
		stop("N x 2 matrix is required for input")
	}
	num = nrow(pairs)

	xyz    = array(0, 6*num)
	bf     = array(0, 2*num)
	atype  = array(0, 2*num)
	resno  = array(0, 2*num)
	atomNo = 0
	contents = array(paste(array(" ", pdbFileChars), collapse=""), num)

	for (pos in 1:num) {
		i = pairs[pos,1]
		j = pairs[pos,2]
		# cat("Pair number: ", i, " - ", j, "\n")
		# add two new atoms
		range = (3*atomNo + 1):(3*atomNo+6)
		xyz[range] = c(as.numeric(pdb$atom[i, c("x","y","z")]),
			       as.numeric(pdb$atom[j, c("x","y","z")]))
		atomNo = atomNo + 2;
		if (!is.null(weights))
			bf[c(atomNo - 1, atomNo)] = weights[i,j]
		atype[c(atomNo - 1, atomNo)] = "H"
		resno[atomNo - 1] = i
		resno[atomNo]     = j

		if (atomNo - 1 < 10)         blancs = "    "
		else if (atomNo - 1 < 100)   blancs = "   "
		else if (atomNo - 1 < 1000)  blancs = "  "
		else if (atomNo - 1 < 10000) blancs = " "
		else stop("Number too large for pdb file. Too many atoms...\n")
		string = paste("CONECT", atomNo - 1, blancs, atomNo, sep="")
		contents[atomNo / 2] = paste(string, paste(array(" ", pdbFileChars -
				     nchar(string)), collapse=""), sep = "")
	}
	
	# Remove unnecessarily allocated space 
	write.pdb(xyz = as.vector(xyz), file = file, b=bf, elety=atype, resno=resno);
	entries = read.fwf(file, pdbFileChars)
	lines = levels(entries[1,])
	# Cut the "END" and "TER" lines
	lines = lines[1:(length(lines) - 2)]

	contents[atomNo / 2 + 1] = "TER   "
	contents[atomNo / 2 + 2] = "END"
	write(file=file, lines, append = FALSE)
	write(file=file, contents, append = TRUE)
}


